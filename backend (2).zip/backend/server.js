const express = require("express")
const dotenv = require("dotenv")
const mongoose = require("mongoose");
var cors = require('cors')
const userRoutes = require("./Routes/userRoutes");
const app = express();
app.use(express.json())
app.use(cors())
dotenv.config();
const connectDB=async()=>{
    console.log('Mongo URL:', process.env.MONGODB_URL)
    await mongoose.connect(process.env.MONGODB_URI)
    .then(()=> console.log('Mongo DB Connected'))
    .catch((e)=>console.log(e))
}

app.use(express.json())
app.use('/users', userRoutes)

app.listen(5050,()=>{
    console.log('Server is Runnig')
    connectDB()
})